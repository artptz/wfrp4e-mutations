# wfrp4e-mutations
WFRP4E module for Foundry based on the Mutation's Handbook by Anders Hellspong


## v1.0.2
Corrected mismatched internal items references
 
## v1.0.1
Added credits inthe Journal

## v1.0
The module includes:
- 87 Mental Mutations, 137 Physical Mutations, including 22 Bestial Body and 7 Unnatural Body Mutations 
- RollTables for general, chaos-god-specific and necromantic Corruption 
- A Macro to generate mutations for a specified Actor, including randomized chat messages
