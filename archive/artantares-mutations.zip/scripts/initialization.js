// Post to console after initialization
Hooks.once("init", () => {
    console.log("The Mutant's Handbook Module was Loaded");
});
